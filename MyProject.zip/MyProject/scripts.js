// Menambahkan kontrol animasi untuk elemen hero
const hero = document.querySelector('.hero');

// Memulai animasi
function startAnimation() {
    hero.style.animationPlayState = 'running';
}

// Menghentikan animasi
function stopAnimation() {
    hero.style.animationPlayState = 'paused';
}

// Contoh: Mulai animasi saat halaman dimuat
window.addEventListener('load', () => {
    startAnimation();
});

// Contoh: Hentikan animasi saat tombol ditekan (tambahkan tombol di HTML jika perlu)
document.getElementById('stopAnimationButton').addEventListener('click', stopAnimation);


// Smooth scroll functionality for navigation
document.querySelectorAll("nav a").forEach(anchor => {
    anchor.addEventListener("click", function(e) {
        e.preventDefault();
        const targetId = this.getAttribute("href").slice(1);
        const targetElement = document.getElementById(targetId);

        if (targetElement) { // Validasi jika elemen target ada
            targetElement.scrollIntoView({
                behavior: "smooth"
            });
        }
    });
});


// Toggle visibility of timeline details
document.querySelectorAll(".toggle-details").forEach(button => {
    button.addEventListener("click", function() {
        const target = document.querySelector(this.dataset.target);

        if (target) { // Validasi jika elemen target ada
            if (target.classList.contains("hidden")) {
                target.classList.remove("hidden");
                target.classList.add("visible");
                this.textContent = "Sembunyikan Detail";
            } else {
                target.classList.remove("visible");
                target.classList.add("hidden");
                this.textContent = "Tampilkan Detail";
            }
        }
    });
});


// Gallery hover effect
document.querySelectorAll(".gallery img").forEach(img => {
    img.addEventListener("mouseover", () => {
        img.style.filter = "brightness(0.5)";
    });
    img.addEventListener("mouseout", () => {
        img.style.filter = "brightness(1)";
    });
});


        


